#include <lcom/lcf.h>
#include "keyboard.h"
#include "KBC.h"

// Variáveis globais
    // ... por declarar

int kbd_subscribe_int(uint8_t *bit_no) {
    /* To be completed by the students */
    printf("%s is not yet implemented!\n", __func__);

    return 1;
}

int kbd_unsubscribe_int() {
    /* To be completed by the students */
    printf("%s is not yet implemented!\n", __func__);

    return 1;
}

void (kbc_ih)() {
    /* To be completed by the students */
}

int kbd_restore_interrupts() {
    /* To be completed by the students */
    printf("%s is not yet implemented!\n", __func__);

    return 1;
}
